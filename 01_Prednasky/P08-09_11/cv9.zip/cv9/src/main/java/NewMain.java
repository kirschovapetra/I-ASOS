
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author edu
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main1(String[] args) {
        List<Ucet> uList = new ArrayList<>();
        uList.add(new Ucet("U001", 100));
        uList.add(new Ucet("U002", 200));
        uList.add(new Ucet("U003", 300));
        uList.add(new Ucet("U004", 400));

        SparkConf conf = new SparkConf().setAppName("meno aplikacie").setMaster("local"); //local[4]
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");

        // parallelize
        JavaRDD<Ucet> udd = sc.parallelize(uList);
        // foreach
        udd.foreach(u->System.out.println("" + u));
        
        // map reduce
        Double d = udd.map(u -> u.getStav()).reduce((a, b) -> a + b);
        System.out.println("" + d);
    }

    public static void main2(String[] args) {
        SparkConf conf = new SparkConf().setAppName("meno aplikacie").setMaster("local[2]");
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");

        // textfile
        JavaRDD<String> rdd = sc.textFile("src/main/resources/data.txt");
        // count
        System.out.println("\npocet riadkov");
        System.out.println("" + rdd.count());

        // first
        System.out.println("\nprvy riadok");
        System.out.println("" + rdd.first());

        // collect
        System.out.println("\nvypis vsetkych riadkov");
        List<String> sList = rdd.collect();
        sList.forEach(s -> System.out.println(s));
                
        // filter
        System.out.println("\npocet riadkov ktore obsahuju slovo riadok");
        System.out.println("" + rdd.filter(s -> s.contains("riadok")).count());

        // CV
//        System.out.println("\nvypis vsetkych riadkov ktore neobsahuju slovo riadok");
        // CV
//        System.out.println("\ndlzky riadkov");

        System.out.println("\ndlzka najdlhsieho riadku");
        System.out.println("" + rdd.map(String::length).reduce(Math::max));

        // JavaPairRDD mapToPair collectAsMap
        System.out.println("\nriadky a ich dlzky");
        JavaPairRDD<String, Integer> rdd2 = rdd.mapToPair(s -> new Tuple2(s, s.length()));
        Map<String, Integer> dlzky = rdd2.collectAsMap();
        dlzky.forEach((k,v)-> System.out.println(k + ":" + v));

        // groupBy sortByKey
        System.out.println("\nnajdlhsi riadok");
        Tuple2<Integer, Iterable<String>> t = rdd.groupBy(s -> s.length()).sortByKey(false).first();
        System.out.println("" + t._1);
        t._2.forEach(s -> System.out.println(s));
    }
///////////////////////////////////////////
// na 9. prednaske som prisiel len potialto    
///////////////////////////////////////////

    public static void main3(String[] args) {
        SparkConf conf = new SparkConf().setAppName("meno aplikacie").setMaster("local[2]");
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");

        JavaRDD<String> rdd = sc.textFile("src/main/resources/data.txt");
//        rdd.collect().forEach(s -> System.out.println(s));
        
        // flatMap
        System.out.println("\nrozdelenie na slova a ich vypis");
        JavaRDD<String> wdd = rdd.flatMap(s -> Arrays.asList(s.split(" ")).iterator());
        wdd.collect().forEach(s -> System.out.println(s));

        // distinct
        System.out.println("\npocet roznych slov");
        System.out.println("" + wdd.distinct().count());

        // countByValue
        System.out.println("\npocetnosti slov");
        Map<String, Long> pocty = wdd.countByValue();
        pocty.keySet().forEach(s -> {
            System.out.println(s + ":" + pocty.get(s));
        });
        
        // CV
        // Pocet roznych slov kratsich ako 5
        // Pocet roznych slov pricom sa nerozlisuju male a velke pismena
        // Pocetnosti slov pricom sa nerozlisuju male a velke pismena
    }

    public static void main4(String[] args) {
        SparkConf conf = new SparkConf().setAppName("meno aplikacie").setMaster("local[2]");
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");

        // wholeTextFiles collectAsMap
        System.out.println("\nmeno-suboru : cely obsah");
        JavaPairRDD<String, String> pdd = sc.wholeTextFiles("src/main/resources");
        pdd.collectAsMap().forEach((k, v) -> System.out.println(k + ":" + v));

        // mapValues
        System.out.println("\nmeno suboru : velkost suboru");
        JavaPairRDD<String, Integer> pdd2 = pdd.mapValues(s->s.length());
        pdd2.collectAsMap().forEach((k, v) -> System.out.println(k + ":" + v));
        
        
        // flatMapValues
        System.out.println("\nmeno suboru : slova");
        JavaPairRDD<String, String> fwdd = pdd.flatMapValues(s -> Arrays.asList(s.split("\\s+")).iterator());
//        wdd.collectAsMap().forEach((k,v)-> System.out.println(k + ":" + v)); // nie je to co sme chceli
        List<Tuple2<String,String>> tl = fwdd.collect(); 
        tl.forEach(t -> System.out.println(t._1 + ":" + t._2));
        
        // reduceByKey
        System.out.println("\nmeno suboru : dlzka najkratsieho slova v subore");   
        fwdd.mapValues(s->s.length()).reduceByKey(Math::min).collectAsMap()
                .forEach((k, v) -> System.out.println(k + " : " + v));
        
        // CV 
        // Pre kazdy subor vypiste meno suboru a najdlhsie slovo v subore
        
        // countByKey
        System.out.println("\nmeno suboru : pocet roznych slov");
        fwdd.distinct().countByKey().forEach((k, v) -> System.out.println(k + ":" + v));
        
        // CV
        // Pre kazde slovo vypiste slovo a pocet suborov v ktorych sa nachadza
        //     Navod: pomocou mapToPair vymente vo dvojiciach ich 1. a 2. polozku
        // Pre kazdy slovo vypiste mena suborov v ktorych sa nachadza - spojene do jedneho retazca
    }

    public static void main5(String[] args) {
        SparkConf conf = new SparkConf().setAppName("meno aplikacie").setMaster("local[2]");
        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.setLogLevel("ERROR");

        JavaRDD<String> rdd1 = sc.textFile("src/main/resources/data.txt")
                .flatMap(s -> Arrays.asList(s.split(" ")).iterator());
        JavaRDD<String> rdd2 = sc.textFile("src/main/resources/data2.txt")
                .flatMap(s -> Arrays.asList(s.split(" ")).iterator());
        
        // intersection
        System.out.println("\nslova ktore sa chadzaju v oboch suboroch");
        rdd1.intersection(rdd2).collect().forEach(s->System.out.println(s));
        
        // subtract
        System.out.println("\npocet roznych slov ktore sa chadzaju v data2.txt ale nechachadzaju v data.txt");
        System.out.println("" + rdd2.distinct().subtract(rdd1.distinct()).count());
        
        // CV 
        // Pocet roznych slov, ktore sa nachadzaju aspon v jednom zo suborov
        // Symetricka diferencia mnoziny slov v suboroch data.txt a data2.txt 
    }
}
