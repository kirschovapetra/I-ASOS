package asos;

public interface IReceiver {
    public void put(String msg);    
}
