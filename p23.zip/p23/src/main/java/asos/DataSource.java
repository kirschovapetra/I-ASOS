package asos;

public class DataSource {
    
    public String getData() {
        return "asos hello";
    }
}
