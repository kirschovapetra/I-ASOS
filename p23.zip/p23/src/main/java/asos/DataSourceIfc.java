package asos;

public interface DataSourceIfc {
    public String getData();
    
}
