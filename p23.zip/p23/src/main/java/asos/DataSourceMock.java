package asos;

public class DataSourceMock implements DataSourceIfc{

    public String getData() {
        return null;
    }
}
